# StepCare (데모)

16채널(발당 8채널 × 2) 압력센서 스마트 인솔로 시니어의 보행을 분석하고,
낙상 위험을 조기에 감지해 보호자·요양기관에 알려주는 케어 플랫폼 **데모 웹앱**입니다.

- `public/index.html` — heycare.co.kr 스타일(히어로 → 문제정의 → 제품 → 라이브데모 → 솔루션구조 → 팀 → 문의)의 랜딩페이지
- `public/demo/index.html` — 실시간 8채널×2 압력 모니터링 + 가상 시니어 5명의 케어 리포트 대시보드
- 모든 인물·수치·팀 정보는 **가상 데모 데이터**입니다 (`public/demo/mock-data.js`).

## 로컬에서 열어보기

파일을 그대로 더블클릭해서 브라우저로 열어도 동작합니다. 로컬 서버로 띄우려면:

```bash
npx serve public -l 5000
# http://localhost:5000        → 랜딩페이지
# http://localhost:5000/demo/  → 라이브 데모 대시보드
```

## GitHub에 올리기 — 저장소명: `insole_footcare`

보안 정책상 제가 대신 로그인하거나 저장소를 만들 수 없어서, 아래 명령어를 그대로 복사해서 직접 실행해 주세요.
(참고: Claude 커넥터 설정에서 GitHub 연동을 승인하시면, 다음부터는 제가 직접 저장소 생성·push까지 대신 해드릴 수 있습니다.)

1. GitHub에서 새 저장소를 만듭니다 → 저장소 이름 `insole_footcare` (Public/Private은 원하는 대로), **README/.gitignore 자동 생성 옵션은 체크하지 마세요.**
2. 아래 명령어 실행:

```bash
cd stepcare-app
git init                     # 이미 초기화되어 있다면 생략
git add .
git commit -m "Initial commit: StepCare demo app"

git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/insole_footcare.git
git branch -M main
git push -u origin main
```

또는 GitHub CLI가 설치되어 있다면 저장소 생성부터 push까지 한 번에:

```bash
cd stepcare-app
gh repo create insole_footcare --public --source=. --remote=origin --push
```

## Firebase Hosting으로 배포하기 — 호스팅 사이트명: `insole`

이 프로젝트는 Firebase의 멀티 사이트 호스팅 기능을 사용해 `insole`이라는 이름의 호스팅 사이트로 배포하도록
`firebase.json`(`"target": "insole"`)과 `.firebaserc`(`targets.hosting.insole`)에 미리 설정되어 있습니다.

1. [Firebase 콘솔](https://console.firebase.google.com/)에서 새 프로젝트를 만듭니다. (프로젝트 ID 예: `insole-footcare`)
2. `.firebaserc` 파일의 `REPLACE_WITH_YOUR_FIREBASE_PROJECT_ID` 두 곳을 실제 프로젝트 ID로 바꾸고 커밋합니다.
3. 아래 명령어로 `insole` 호스팅 사이트를 만들고 target을 연결합니다.

```bash
npm install -g firebase-tools        # 최초 1회
firebase login                       # 브라우저에서 본인 계정으로 로그인

firebase hosting:sites:create insole                 # "insole" 사이트 생성 (전역으로 이름이 겹치면 다른 이름 제안됨)
firebase target:apply hosting insole insole          # firebase.json의 target "insole" ↔ 방금 만든 사이트 연결

firebase deploy --only hosting:insole
```

배포가 끝나면 `https://insole.web.app` (이름이 겹치면 콘솔에 안내되는 대체 URL)로 접속할 수 있습니다.

4. `insole_footcare` GitHub 저장소를 push한 뒤, 브랜치 push마다 자동 배포되도록 GitHub Actions 연동:

```bash
firebase init hosting:github
# → 연동할 GitHub 저장소로 <YOUR_GITHUB_USERNAME>/insole_footcare 선택
# → main 브랜치에 push될 때 자동 배포되도록 설정 (Yes)
```

이 명령은 `.github/workflows/firebase-hosting-merge.yml`을 자동 생성해서, 이후에는 `git push`만 하면
GitHub Actions가 `insole` 호스팅 사이트로 자동 배포합니다.

## 8채널 센서 레이아웃

각 발에 다음 8개 압력 지점을 배치했습니다 (`public/demo/app.js`의 `SENSOR_LAYOUT`).

| 구역 | 센서 |
| --- | --- |
| 전족부 (4) | 무지(엄지), 중족골 내측·중앙·외측 |
| 중족부 (2) | 아치 내측·외측 |
| 후족부 (2) | 뒤꿈치 내측·외측 |

실제 인솔 하드웨어와 연동할 때는 `demo/index.html`의 `Socket` 모드로 전환한 뒤,
아래 형식의 JSON 프레임을 WebSocket으로 전송하면 됩니다.

```json
{
  "timestamp": 12345,
  "left":  { "raw": [8개 정수], "acc": { "x": 0, "y": 0.9, "z": 0.2 } },
  "right": { "raw": [8개 정수], "acc": { "x": 0, "y": 0.9, "z": 0.2 } }
}
```
